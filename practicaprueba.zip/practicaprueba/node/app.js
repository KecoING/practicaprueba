const http = require('http');
const fs = require('fs');
const express = require('express');
const mysql = require('mysql2');
const { connect } = require('http2');

const server = express();

server.use(express.urlencoded({extended: true}));

server.use(express.static('public'));

const conexion = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'Mysql2026!',
    database:'deudaskenny'
});

    const cabecera = fs.readFileSync('public/header.html', 'utf8');
    const final = fs.readFileSync('public/footer.html', 'utf8');

server.post("/deudaskeco", (req, res) =>{
    
    const correo = req.body.correo;
    const clave = req.body.clave;

    if((correo=="kenny@control.com")&&(clave=="1234"))
    {
        const contenido = `
            <center>
            <img src="images/gasto.webp" class="img-gasto">
            <h1> Aqui puedes consultar por tus deudas en tu celular </h1>
            <br>
            <p> accede por medio del codigo QR al gestor de deudas </p>
            <br>
            <br>
            <img src="images/qr.png">
            <br>
            <br>
            <br>
            <p> accede aqui para verlas en el navegador </p>
            <br>
            <a href="/deudas">VER LISTADO DE DEUDAS</a>
            </center>
            `;

        res.send(cabecera+contenido+final);
    }

    else
    {
        const contenido = `
            <center>
            <img src="images/gasto.webp" class="img-gasto">
            <h1> LAS CREDENCIALES NO COINCIDEN </h1>
            <br>
            <img src="images/error.webp" class="img-error">
            </center>
            `;

        res.send(cabecera+contenido+final);
    }
});

server.get("/deudas", (req, res) =>{

    const resultado = conexion.query("select * from deudas", (error,data)=> {
        let fila = ``;
        if(error)
        {
            const fila = `
            <tr>
            <td colspan="6"> NO EXISTEN REGISTROS </td>
            </tr>
            `;

        }
        else{
            
            for(const i of data){
                fila += `
                    
                    <tr>
                        <td>${i.id}</td><td>${i.categoria}</td><td>${i.tipo}</td><td>${i.descripcion}</td><td>${i.monto}</td><td><a href="/editar_deuda?id=${i.id}">Editar</a>&nbsp; <a href="/eliminar_deuda?id=${i.id}">Eliminar</a></td>
                    </tr>
                    
                `;
            }

        }
        const contenido = `
            <center>
                <img src="images/gasto.webp" class="img-gasto">
                <table border="1" width="600">
                    <tr>
                        <td>
                                <table width="100%" class="tabla_deudas">
                                        <tr>
                                            <td>ID</td><td>CATEGORIA</td><td>TIPO</td><td>DESCRIPCION</td><td>MONTO</td><td>ACCION</td>
                                        </tr>
                                        ${fila}
                                </table>
                        </td>
                    </tr>
                </table>
            <br><input type="button" name="btn_nuevo" value="NUEVA DEUDA" onClick="location='/nueva_deuda'">
            </center>
        `;

        res.send(cabecera+contenido+final);

    });
    
});

server.get("/editar_deuda", (req, res) => {

        const id_recibido = req.query.id;
        conexion.query("select * from deudas where id=?",[id_recibido], (error,data) => {

            if(error|| data.length==0){
                    const contenido = `
                    <center>
                    <img src="images/gasto.webp" class="img-gasto">
                    <h1> DEUDA NO ENCONTRADA  </h1>
                    <br>
                    <img src="images/error.webp" class="img-error">
                    <br>
                    <br>
                    <br>
                    <input type="button" name="btn" value="Regrsar al listado de deudas" onClick="location='/deudas';"
                    </center>
                    `;
                    res.send(cabecera+contenido+final);
            }
            else {
                const categoria_recibido = data[0].categoria;
                const tipo_recibido = data[0].tipo;
                const descripcion_recibido = data[0].descripcion;
                const monto_recibido = data[0].monto;

                const contenido = `
                    <center>
                    <img src="images/gasto.webp" class="img-gasto">
                    <form name="editard" action="/actualizar_deuda" method="POST">
                    <input type="hidden" name="id" value="${id_recibido}">
                    <table border="2" width ="600">
                        <tr>
                            <td>
                                <table style="width:100%;  style="text-align:center;" class="tabla_editardeuda">
                                    <tr>
                                        <td>CATEGORIA</td><td><input type="text" name="categoria" value="${categoria_recibido}" ></td>
                                    </tr>
                                    <tr>
                                        <td>TIPO</td><td><input type="text" name="tipo" value="${tipo_recibido}" readonly></td>
                                    </tr>
                                    <tr>
                                        <td>DESCRIPCION</td><td><input type="text" name="descripcion" value="${descripcion_recibido}" ></td>
                                    </tr>
                                    <tr>
                                        <td>MONTO</td><td><input type="number" name="monto" value="${monto_recibido}" ></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" align="center"><input type="submit" name="btn_actualizar" value="actualizar deuda"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                    </form>
                    </center>
                    `;
                    res.send(cabecera+contenido+final);
            }
        });
});

server.post("/actualizar_deuda", (req, res) => {

    const id_recibido = req.body.id;
    const categoria_recibido = req.body.categoria;
    const descripcion_recibido = req.body.descripcion;
    const monto_recibido = req.body.monto;


    if (!id_recibido || !categoria_recibido || !descripcion_recibido || !monto_recibido) {
        const contenido = `
        <center>
        <img src="images/gasto.webp" class="img-gasto">
        <h1> TODOS LOS CAMPOS SON OBLIGATORIOS </h1>
        <br>
        <img src="images/error.webp" class="img-error">
        <br><br><br>
        <input type="button" name="btn" value="Regresar al listado de deudas" onClick="location='/deudas';">
        </center>
        `;
        return res.send(cabecera+contenido+final);
    }

    if (categoria_recibido.trim().length < 3 || categoria_recibido.trim().length > 30) {
        const contenido = `
        <center>
        <img src="images/gasto.webp" class="img-gasto">
        <h1> LA CATEGORIA DEBE TENER ENTRE 3 Y 30 CARACTERES </h1>
        <br>
        <img src="images/error.webp" class="img-error">
        <br><br><br>
        <input type="button" name="btn" value="Regresar al listado de deudas" onClick="location='/deudas';">
        </center>
        `;
        return res.send(cabecera+contenido+final);
    }


    const formatoCategoria = /^[a-zA-ZÀ-ÿ\s]+$/;
    if (!formatoCategoria.test(categoria_recibido)) {
        const contenido = `
        <center>
        <img src="images/gasto.webp" class="img-gasto">
        <h1> LA CATEGORIA SOLO PUEDE CONTENER LETRAS </h1>
        <br>
        <img src="images/error.webp" class="img-error">
        <br><br><br>
        <input type="button" name="btn" value="Regresar al listado de deudas" onClick="location='/deudas';">
        </center>
        `;
        return res.send(cabecera+contenido+final);
    }


    if (descripcion_recibido.trim().length < 3 || descripcion_recibido.trim().length > 100) {
        const contenido = `
        <center>
        <img src="images/gasto.webp" class="img-gasto">
        <h1> LA DESCRIPCION DEBE TENER ENTRE 3 Y 100 CARACTERES </h1>
        <br>
        <img src="images/error.webp" class="img-error">
        <br><br><br>
        <input type="button" name="btn" value="Regresar al listado de deudas" onClick="location='/deudas';">
        </center>
        `;
        return res.send(cabecera+contenido+final);
    }


    const formatoMonto = /^\d+(\.\d{1,2})?$/;
    if (!formatoMonto.test(monto_recibido) || parseFloat(monto_recibido) <= 0) {
        const contenido = `
        <center>
        <img src="images/gasto.webp" class="img-gasto">
        <h1> EL MONTO DEBE SER UN NUMERO POSITIVO VALIDO </h1>
        <br>
        <img src="images/error.webp" class="img-error">
        <br><br><br>
        <input type="button" name="btn" value="Regresar al listado de deudas" onClick="location='/deudas';">
        </center>
        `;
        return res.send(cabecera+contenido+final);
    }

    if (parseFloat(monto_recibido) > 999999.99) {
        const contenido = `
        <center>
        <img src="images/gasto.webp" class="img-gasto">
        <h1> EL MONTO EXCEDE EL LIMITE PERMITIDO </h1>
        <br>
        <img src="images/error.webp" class="img-error">
        <br><br><br>
        <input type="button" name="btn" value="Regresar al listado de deudas" onClick="location='/deudas';">
        </center>
        `;
        return res.send(cabecera+contenido+final);
    }

    conexion.query(
        "update deudas set categoria=?, descripcion=?, monto=? where id=?",
        [categoria_recibido.trim(), descripcion_recibido.trim(), monto_recibido, id_recibido],
        (error, data) => {
            if (error) {
                const contenido = `
                <center>
                <img src="images/gasto.webp" class="img-gasto">
                <h1> ERROR AL ACTUALIZAR LA DEUDA </h1>
                <br>
                <img src="images/error.webp" class="img-error">
                </center>
                `;
                return res.send(cabecera+contenido+final);
            }
            res.redirect("/deudas");
        }
    );
});

/*server.post("/actualizar_deuda", (req, res) => {

    const id_recibido = req.body.id;
    const categoria_recibido = req.body.categoria;
    const descripcion_recibido = req.body.descripcion;
    const monto_recibido = req.body.monto;
    

    conexion.query("update deudas set categoria=?, descripcion=?, monto=? where id=?", [categoria_recibido,descripcion_recibido,monto_recibido,id_recibido], (error,data) => {
        if(error|| data.length==0){
                    const contenido = `
                    <center>
                    <img src="images/gasto.webp" class="img-gasto">
                    <h1> ERROR AL ACTUALIZAR LA DEUDA</h1>
                    <br>
                    <img src="images/error.webp" class="img-error">
                    <br>
                    <br>
                    <br>
                    <input type="button" name="btn" value="Regresar al listado de deudas" onClick="location='/deudas';">
                    </center>
                    `;
                    res.send(cabecera+contenido+final);
            }

        else {
                const contenido = `
                    <script>
                        alert("Informacion actualizada");\n
                        location="/deudas";
                    </script>
                    `;
                res.send(cabecera+contenido+final);
        }
    });
});*/

server.get("/eliminar_deuda", (req, res) => {

    const id_recibido = req.query.id;
    conexion.query("select* from deudas where id=?", [id_recibido], (error,data) => {

        if(error|| data.length==0){
                    const contenido = `
                    <center>
                    <img src="images/gasto.webp" class="img-gasto">
                    <h1> ERROR AL ELIMINAR LA DEUDA </h1>
                    <br>
                    <img src="images/error.webp" class="img-error">
                    <br>
                    <br>
                    <br>
                    <input type="button" name="btn" value="Regresar al listado de deudas" onClick="location='/deudas';">
                    </center>
                    `;
                    res.send(cabecera+contenido+final);
        }
        else {
            const categoria_deuda =data[0].categoria;
            const contenido = `
                    <center>
                    <img src="images/gasto.webp" class="img-gasto">
                    <h1> Se eliminara de forma permenente la deuda <b>${categoria_deuda}?</b></h1>
                    <br>
                    <h1>ESTA SEGURO DE ELIMINAR ESTA DEUDA?</h1>
                    <br>
                    <br>
                    <input type="button" name="btn1" value="SI" onClick="location='/confirmar_eliminacion?id=${id_recibido}';">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="button" name="btn1" value="NO" onClick="location='/deudas';">
                    </center>
                    `;
                    res.send(cabecera+contenido+final);
        }
    });

});

server.get("/confirmar_eliminacion",(req,res)=>{

        const id_recibo= req.query.id;
        
        conexion.query("delete from deudas where id=?",[id_recibo],(error,data)=>{
            if(error||data.length==0){
                    const contenido = `
                    <center>
                    <img src="images/gasto.webp" class="img-gasto">
                    <h1>ERROR AL ELIMINAR</h1>
                    <br>
                    <br>
                    <img src="images/error.webp" class="img-error">
                    <br>
                    <input type="button" name="btn" value="Regresar al Listado de deuda" onClick="location='/deudas';"
                    </center>
                    `;
                    res.send(cabecera+contenido+final);
            }
            else{
                const contenido = `
                <script>
                    alert("Informacion Eliminada");\n
                    location="/deudas";
                </script>
                    `;
                    res.send(cabecera+contenido+final);
            }

        });

});

server.get("/nueva_deuda", (req, res) => {
                
                const contenido = `
                    <center>
                    <img src="images/gasto.webp" class="img-gasto">
                    <form name="editard" action="/insertar_deuda" method="POST">
                    <table border="2" width ="600">
                        <tr>
                            <td>
                                <h1> NUEVA DEUDA </h1>
                                <table style="width:100%;  style="text-align:center;" class="tabla_editardeuda">
                                    <tr>
                                        <td>CATEGORIA</td><td><input type="text" name="categoria" value="" </td>
                                    </tr>
                                    <tr>
                                        <td>TIPO</td><td><input type="text" name="tipo" value="" ></td>
                                    </tr>
                                    <tr>
                                        <td>DESCRIPCION</td><td><input type="text" name="descripcion" value=""></td>
                                    </tr>
                                    <tr>
                                        <td>MONTO</td><td><input type="number" name="monto" value=""></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" align="center"><input type="submit" name="btn_ingresar" value="Crear una nueva deuda"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                    </form>
                    </center>
                    `;
                    res.send(cabecera+contenido+final);
});

server.post("/insertar_deuda",(req,res)=>{

        const categoria = req.body.categoria;
        const tipo = req.body.tipo;
        const descripcion = req.body.descripcion;
        const monto = req.body.monto;

        conexion.query("insert into deudas(categoria,tipo,descripcion,monto) values(?,?,?,?) ",[categoria,tipo,descripcion,monto],(error,data)=>{
            if(error||data.length==0){
                    const contenido =`
                    <center>
                    <img src="images/gasto.webp" class="img-gasto">
                    <h1>ERROR AL INSERTAR</h1>
                    <br>
                    <img src="images/error.gif"><br><br>
                    <input type="button" name="btn" value="Regresar al Listado de deudas" onClick="location='/deudas';"
                    </center>
                    `;
                    res.send(cabecera+contenido+final);
            }
            else {
                    const contenido = `
                        <script>
                            alert("Deudas agregada correctamente");\n
                            location="/deudas";
                        </script>
                    `;
                    res.send(cabecera+contenido+final);
            }

        });

});

server.listen(3000, () => {
    console.log('Servidor iniciado en puerto 3000 (OK)');
});